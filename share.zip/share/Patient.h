#ifndef PATIENT_H_INCLUDED
#define PATIENT_H_INCLUDED

#include <iostream>
#include<winsock.h>
#include"mysql.h"
#include<windows.h>
#include<sstream>
#include<string>
#include<iomanip>
using namespace std;

char * day(int i)
{
    switch(i)
    {
    case 3:
        return "Monday";
    case 4:
        return "Tuesday";
    case 5:
        return "Wednesday";
    case 6:
        return "Thursday";
    case 7:
        return "Friday";
    case 8:
        return "Saturday";
    }
}


class Patient
{
    string id;
    int age;
public:
    void login(MYSQL*conn);
    void reg(MYSQL*conn);
    void display(MYSQL*conn);
};

void Patient ::login(MYSQL*conn)
{
    MYSQL_ROW row;
    MYSQL_RES* res;
    string email,pass;
    cout<<setw(62)<<" "<<"Enter email:";
    cin>>email;
    cout<<setw(62)<<" "<<"Enter password:";
    cin>>pass;
    stringstream s;
    s<<"select * from login where (email,password,user)=("<<"'"<<email<<"','"<<pass<<"',0"<<");";
    string qs=s.str();
    int qstate=mysql_query(conn,qs.c_str());
    if(qstate==0)
    {
         res = mysql_store_result(conn);
         int i=0;
        while(row = mysql_fetch_row(res))
        {
            i=1;
            cout<<endl<<endl<<setw(62)<<" "<<"-----Welcome-----"<<endl;
            cout<<setw(62)<<" "<<setw(30)<<left<<row[0]<<setw(20)<<row[1]<<setw(20)<<row[2];
            id=row[0];
            return ;
        }
        if(i==0)
            cout<<setw(62)<<" "<<"Incorrect password or email....Try Again\n";
            exit(0);

    }
    else
    {
        cout<<setw(62)<<" "<<"Error in login ..please try again\n";
        exit(0);
    }

}

void Patient::reg(MYSQL*conn)
{
    MYSQL_ROW row;
    MYSQL_RES* res;

    string email,pass,confirm;
    cout<<setw(62)<<" "<<"Enter email:";
    cin>>email;
    cout<<setw(62)<<" "<<"Enter Password:";
    cin>>pass;
    cout<<setw(62)<<" "<<"Confirm Password:";
    cin>>confirm;
    while(confirm!=pass)
    {
        cout<<setw(62)<<" "<<"Password does not match\n";
        cout<<setw(62)<<" "<<"Enter Password:";
        cin>>pass;
        cout<<setw(62)<<" "<<"Confirm Password:";
        cin>>confirm;
    }
    stringstream s1;
    s1<<"select * from login where email='"<<email<<"';";

    string qs=s1.str();
    int qstate=mysql_query(conn,qs.c_str());
    if(qstate==0)
    {
        res=mysql_store_result(conn);
        int i=0;
        while(row=mysql_fetch_row(res))
            i++;

        if(i!=0)
        {
            cout<<setw(62)<<" "<<"Email address already exists\n";
            cout<<setw(62)<<" "<<"Please Login:\n";
            login(conn);
            return;
        }
    }
    int role=0;//for patient
    stringstream s;

    //CODE FOR OTP


    s<<"insert into login values("<<"'"<<email<<"'"<<",'"<<pass<<"','"<<role<<"');";
    qs=s.str();
     qstate=mysql_query(conn,qs.c_str());
    if(qstate==0)
    {
        cout<<setw(62)<<" "<<"Registration done\n";
    }
    else
    {
        cout<<setw(62)<<" "<<"Registration failed...please try again\n";
        exit(0);
    }
    id=email;

    return ;
}

void Patient::display(MYSQL*conn)
{
     MYSQL_ROW r;
    MYSQL_RES* result;
    cout<<setw(54)<<" "<<"---LIST OF DOCTORS---\n";
    int q_result=mysql_query(conn,"select * from Doctors");
    if(q_result!=0)
    {
        cout<<setw(62)<<" "<<"Error...Please Try Later\n";
        exit(0);
    }
        result=mysql_store_result(conn);
        cout<<setw(15)<<" "<<"|        DOCTOR NAME        |"<<"    DEPARTMENT          |";
        cout<<setw(12)<<" "<<" AVAILABILITY DAYS "<<setw(5)<<" "<<"|\n";
        cout<<setw(15)<<" "<<setfill('-')<<setw(90)<<" "<<endl;
        cout<<setfill(' ');
        while(r=mysql_fetch_row(result))
        {
           cout<<setw(15)<<" ";
           cout<<"| ";
           cout<<left <<setw(5)<<" "<<setw(20)<<r[1]<<" | ";
           cout<<setw(2)<<" "<<left<<setw(20)<<r[2]<<" | ";
            stringstream s;
           for(int i=3;i<9;i++)
           {
               if(strcmp(r[i],"1")==0)
                s<<day(i)<<",";
           }
           s<<"\b  ";
           cout<<setw(30)<<s.str();
           cout<<setw(6)<<" "<<" | ";
           cout<<endl;
            cout<<setw(15)<<" "<<setfill('-')<<setw(90)<<" "<<endl;
            cout<<setfill(' ');

        }

}

#endif // PATIENT_H_INCLUDED
